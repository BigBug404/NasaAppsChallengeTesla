package com.example.talipzhan.trackfire;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    public Button button_place;
    DatabaseReference dref;
    private static final int REQUEST_CALL = 1;
    private static final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;
    public  static String place;
    public int location = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_place =findViewById(R.id.button_place);

        dref= FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                place=dataSnapshot.child("location").getValue().toString();
                location = Integer.parseInt(place);
                button_place.setText("SAFE");
                if(location==2){
                    button_place.setText("FIRE");
                    button_place.setBackgroundColor(Color.RED);

                    String phoneNumber = "87752729589";

                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            android.Manifest.permission.CALL_PHONE) !=PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.CALL_PHONE}, REQUEST_CALL);
                    } else {
                        String dial = "tel:" + phoneNumber;
                        startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
  }
}
